package com.js.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.js.dao.LapCRUD;
import com.js.dto.Laptop;


@Controller // if we dont set this dispatcher servlet cant see
public class LaptopController {

	@Autowired
	LapCRUD lc;

	@RequestMapping("/load")
	public ModelAndView loadLaptop() {
		ModelAndView mv = new ModelAndView("loadlaptop.jsp");
		mv.addObject("laptop", new Laptop());
		return mv;

	}

	@RequestMapping("/save")
	public ModelAndView saveLaptop(@ModelAttribute Laptop l) {
		ModelAndView mv=new ModelAndView("welcome.jsp");
		if(lc.insert(l)) {
			mv.addObject("msg","Saved successfully");
		}else {
			mv.addObject("msg", "failed Successfully");
			
		}
		return mv;
	}
	
	@RequestMapping("/edit")
	public ModelAndView updatedlaptop(@ModelAttribute Laptop laptop) {
		ModelAndView mv=new ModelAndView("display");
		if(lc.updateLaptop(laptop.getId(), laptop)) {
			mv.addObject("updatemsg", "Updated Successfully");
			
		}
		else {
			mv.addObject("updatemsg", "Failed to Update");
		}
		return mv;
		
	}
	@RequestMapping("/display")
	public ModelAndView displayLaptop() {
		java.util.List<Laptop> l= lc.getAllLap();
		ModelAndView mv=new ModelAndView("display.jsp");
		mv.addObject("All",l);
		return mv;
	}
	
	@RequestMapping("/delete")
	public ModelAndView deleteLaptop(@RequestParam int id) {
		ModelAndView mv=new ModelAndView("display");
		if(lc.delete(id)) {
		mv.addObject("del", "Deleted successfully");
	}
		else {
			mv.addObject("del", "Not Deleted Something went Wrong");
		}
		return mv;
	}
	
	@RequestMapping("/update")
	public ModelAndView updateLaptop(@RequestParam int id) {
		ModelAndView mv=new ModelAndView("update.jsp");
		Laptop l=lc.LaptopByID(id);
		mv.addObject("obj", l);
		return mv;
		
		
		
		
	}
	

}
