package com.js.dao;

	import java.util.List;

	import javax.persistence.EntityManager;
	import javax.persistence.EntityManagerFactory;
	import javax.persistence.EntityTransaction;
	import javax.persistence.Persistence;
	import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.js.dto.Laptop;
	
	@Component
	public class LapCRUD {
		@Autowired
		 EntityManagerFactory emf;
		
		
		public boolean insert(Laptop l) {
			EntityManager em= emf.createEntityManager();
			EntityTransaction et = em.getTransaction();
			
			et.begin();
			em.persist(l);
			et.commit();
			
			if(em.find(Laptop.class, l.getId())==null)
				return false;
				return true;
		}
		
		public boolean delete(int id) {
			EntityManager em=emf.createEntityManager();
			EntityTransaction et=em.getTransaction();
			Laptop l=em.find(Laptop.class, id);
			if(l!=null) {
				et.begin();
				em.remove(l);
				et.commit();
				return true;
			}
			else {
				return false;
			}

		}
		
		public Laptop LaptopByID(int id) {
			EntityManager em=emf.createEntityManager();
			return em.find(Laptop.class, id);
		}
		
		public boolean updateLaptop(int id,Laptop newLap) {
			EntityManager em=emf.createEntityManager();
			EntityTransaction et=em.getTransaction();
			Laptop l=em.find(Laptop.class, id);
			if(l==null) {
				return false;
			}
			else {
				newLap.setId(l.getId());
				et.begin();
				em.merge(newLap);
				et.commit();
				return true;
			}
		}
		
		public List<Laptop> getAllLap(){
			EntityManager em=emf.createEntityManager();
			Query q = em.createQuery("select l from Laptop l");
			return q.getResultList();
		}
	

}
