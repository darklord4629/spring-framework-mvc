package com.js.dto;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="com.js")
public class Config {
	
	@Bean//when autowired is called it comes here and takes object
	public EntityManagerFactory getEntityManagerFactory() {
		return Persistence.createEntityManagerFactory("laptop_store");
	}

}
